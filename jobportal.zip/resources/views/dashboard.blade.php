@extends('layouts.dash')
@section('content')


        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="text-white mt-5 mb-5">Welcome back, <b>{{Auth::user()->name }}</b></p>
                </div>
            </div>
            <!-- row -->
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 tm-block-col">
                    <div class="tm-bg-primary-dark tm-block">
                        <form action="" method="post">
                            @csrf
                            <div class="single-post d-flex flex-row">
								<div class="thumb">
									<img src="img/post.png" alt="">
									
								</div>
								<div class="details">
									<div class="title d-flex flex-row justify-content-between">
										<div class="titles">
											<a href="#" class="text-white"><h4>Creative Art Designer</h4></a>
											<h6>Premium Labels Limited</h6>					
										</div>	
									</div>
									<p>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc ididunt ut dolore magna aliqua.
									</p>
									<h5>Job Nature: Full time</h5>
									<p class="address"><span class="lnr lnr-map"></span> 56/8, Panthapath Dhanmondi Dhaka</p>
									<p class="address"><span class="lnr lnr-database"></span> 15k - 25k</p>
                                    <button type="submit" class="btn btn-primary">Apply</button>
								</div>
							</div>
                        </form>
                    </div>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 tm-block-col">
                    <div class="tm-bg-primary-dark tm-block">
                        <form action="" method="post">
                            @csrf
                            <div class="single-post d-flex flex-row">
								<div class="thumb">
									<img src="img/post.png" alt="">
									
								</div>
								<div class="details">
									<div class="title d-flex flex-row justify-content-between">
										<div class="titles">
											<a href="#" class="text-white"><h4>Creative Art Designer</h4></a>
											<h6>Premium Labels Limited</h6>					
										</div>	
									</div>
									<p>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc ididunt ut dolore magna aliqua.
									</p>
									<h5>Job Nature: Full time</h5>
									<p class="address"><span class="lnr lnr-map"></span> 56/8, Panthapath Dhanmondi Dhaka</p>
									<p class="address"><span class="lnr lnr-database"></span> 15k - 25k</p>
                                    <button type="submit" class="btn btn-primary">Apply</button>
								</div>
							</div>
                        </form>
                    </div>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 tm-block-col">
                    <div class="tm-bg-primary-dark tm-block">
                        <form action="" method="post">
                            @csrf
                            <input type="hidden" name="jobtitle" value="Product Manager">
                            <input type="hidden" name="jobtitle" value="Product Manager">
                            <input type="hidden" name="jobtitle" value="Product Manager">
                            <div class="single-post d-flex flex-row">
								<div class="thumb">
									<img src="img/post.png" alt="">
									
								</div>
								<div class="details">
									<div class="title d-flex flex-row justify-content-between">
										<div class="titles">
											<a href="#" class="text-white"><h4>Product Manager</h4></a>
											<h6>Premium Labels Limited</h6>					
										</div>	
									</div>
									<p>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc ididunt ut dolore magna aliqua.
									</p>
									<h5>Job Nature: Full time</h5>
									<p class="address"><span class="lnr lnr-map"></span> 56/8, Panthapath Dhanmondi Dhaka</p>
									<p class="address"><span class="lnr lnr-database"></span> 15k - 25k</p>
                                    <button type="submit" class="btn btn-primary">Apply</button>
								</div>
							</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    
@endsection