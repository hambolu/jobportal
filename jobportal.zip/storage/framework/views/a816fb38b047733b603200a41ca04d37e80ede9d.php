<a href="/">
    <img src="img/logo.png" alt="" srcset="">
</a>
<?php /**PATH /home/hambolu/jobportal/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>